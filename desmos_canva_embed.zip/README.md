
# Desmos → Canva (Advanced Embed Wrapper)

This folder contains a minimal **HTML wrapper** for a Desmos graph so that you can host it on the web and then **Embed** the hosted URL into **Canva**.

> ⚠️ Canva does not accept raw `<iframe>` code directly inside a design. But it *can* embed a URL that itself contains an iframe. That's what this wrapper provides.

---

## Quick Start

1. **Get your Desmos share link**
   - Open your Desmos graph → **Share** → **Copy Link**.
   - Make sure the URL ends with `?embed`. If not, add `?embed` manually.

2. **Edit `index.html`**
   - Replace `DESMOS_EMBED_URL` with your Desmos share link (including `?embed`). Example:
     ```html
     <iframe src="https://www.desmos.com/calculator/abc123?embed" ...></iframe>
     ```

3. **Host the page**
   - **GitHub Pages** (free):
     - Create a new repo (e.g., `desmos-canva`).
     - Upload `index.html` (and optionally this README).
     - Go to **Settings → Pages → Deploy from branch** and select your default branch.
     - After a minute, you'll get a URL like `https://<username>.github.io/desmos-canva/`.
   - **Netlify** (free tier):
     - Go to https://app.netlify.com/drop
     - Drag-and-drop the folder. Netlify will give you a live site URL instantly.

4. **Embed into Canva**
   - Open your Canva design → **Apps** (left panel) → **Embed**.
   - Paste the **hosted URL** (from GitHub Pages / Netlify).
   - You'll see the live, interactive Desmos inside the design frame (works best when presenting online).

---

## Notes & Tips

- **Interactivity:** The embed will remain interactive **when viewed online** (e.g., Present, Canva share link). If you export as **PDF/PNG/MP4**, interactivity is not possible.
- If Canva shows a blank frame, try another host (e.g., switch GitHub Pages ↔ Netlify). Some hosts or org settings add security headers that block embedding.
- The wrapper uses a fullscreen responsive iframe that fills whatever size Canva gives it. You can control the aspect ratio via the element's size inside Canva.

---

## Troubleshooting

- **Nothing shows up**: Confirm your Desmos link is publicly accessible and includes `?embed`.
- **Blocked by browser**: Some environments add `X-Frame-Options` or `Content-Security-Policy` headers which can block embedding. Use a host that does **not** set restrictive headers by default.
- **Scrollbars or padding**: This wrapper removes margins and uses `position: absolute` so it should fill the frame edge-to-edge.

Happy graphing!
